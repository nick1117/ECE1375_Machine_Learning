import numpy as np

def logReg_multi(X_train, y_train, X_test):
    unique_values = np.unique(y_train)
    for c in range(unique_values):
        y_predict = 1
    return y_predict